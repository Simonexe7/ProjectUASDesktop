/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projectuas;
import java.awt.event.KeyEvent;
import static java.lang.System.err;
import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet; 
import java.sql.SQLException; 
import javax.swing.JOptionPane; 
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;


/**
 *
 * @author asus
 */
public class JFrame_Produk extends javax.swing.JFrame {
    String harga,diskon;
    /**
     * Creates new form JFrame_Produk
     */
    public JFrame_Produk() {
        initComponents();
        datatotabel();
        supplierComboBox();
    }
    
    private void supplierComboBox()
    {
        try{
          
            Statement stat=(Statement)Koneksi_DB.GetKoneksi().createStatement();
              
              String sql="SELECT * FROM tsupplier";
              ResultSet rs=stat.executeQuery(sql);
              
            while (rs.next()) {                
                   jComboSupplier.addItem(rs.getString("namasupplier")+"-"+rs.getString("kodesupplier"));
            }
            
            rs.last();
            int jumlahdata = rs.getRow();
            rs.first();
       
        }catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal mendapatkan supplier","Error",JOptionPane.ERROR_MESSAGE);
        }        
    }//end method
     
    public void AturKolom()
    {
         TableColumn column;
        jTableProduk.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = jTableProduk.getColumnModel().getColumn(0);
        column.setPreferredWidth(75);
        column = jTableProduk.getColumnModel().getColumn(1);
        column.setPreferredWidth(300);
        column = jTableProduk.getColumnModel().getColumn(2);
        column.setPreferredWidth(75);
        column = jTableProduk.getColumnModel().getColumn(3);
        column.setPreferredWidth(75);
        column = jTableProduk.getColumnModel().getColumn(4);
        column.setPreferredWidth(75);
        column = jTableProduk.getColumnModel().getColumn(5);
        column.setPreferredWidth(75);
            
    }//AKHIR METHOR

    
    public void datatotabel(){
        DefaultTableModel tb= new DefaultTableModel();
        // Memberi nama pada setiap kolom tabel
        tb.addColumn("Id Produk");
        tb.addColumn("Nama Produk");
        tb.addColumn("Supplier");
        tb.addColumn("Price");
        tb.addColumn("Diskon");          
        tb.addColumn("CostPrice");
        tb.addColumn("InStock");
        tb.addColumn("Total Stock");
       
        jTableProduk.setModel(tb);
        try{
        // Mengambil data dari database
        Statement stat=(Statement)Koneksi_DB.GetKoneksi().createStatement();
                       
        String SqlC="select a.itemID, a.namaproduk, a.totalstock, b.Price, b.Disc, b.CostPrice, b.instock, c.namasupplier from tmasterid a,tdetailProduk b, tsupplier c where a.itemID=b.kodeproduk AND c.kodesupplier = b.kodesupplier";
        ResultSet res=stat.executeQuery(SqlC);
                
         while (res.next())
        {
        // Mengambil data dari database berdasarkan nama kolom pada tabel
            // Lalu di tampilkan ke dalam JTable
            tb.addRow(new Object[]{
            res.getString("itemID"),
            res.getString("NamaProduk"),
            res.getString("namasupplier"),
            res.getString("price"),
            res.getString("Disc"),
            res.getString("CostPrice"),  
            res.getString("instock"),
            res.getString("totalstock")
           });
          }
         //Aturkolom(); //pemanggilan class untuk mengatur kolom
        }catch (SQLException e){
            JOptionPane.showMessageDialog(this, "Gagal menampilkan data produk : "+e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }       
        AturKolom();
    }//end method
 
    public void bersihkanlayar()
    {
        jTextNamaProduk.setText("");
        jTextHarga.setText("");
        jTextDiskon.setText("");
        jTextCostPrice.setText("");
        jTextNamaProduk.requestFocus();
    }//akhir method
    
    public void simpandata()
    {
        String supplier=jComboSupplier.getSelectedItem().toString();
        String kdsupplier=supplier.substring(supplier.length()-1);
                 
        try{
            Statement StrI=(Statement)Koneksi_DB.GetKoneksi().createStatement();
                    
            String SqlI="Insert into tmasterid values(DEFAULT, '"+ jTextNamaProduk.getText() +"',"+ jTextHarga.getText() +","+ jSpinnerTStock.getValue() +")";
            StrI.executeUpdate(SqlI);
            ResultSet rs = StrI.executeQuery("SELECT itemID FROM tmasterid WHERE namaproduk = '"+ jTextNamaProduk.getText() +"'");
            String kdproduk;
            if(rs.next()){
                kdproduk = rs.getString("itemID");
                String SqlIPD="insert into tdetailproduk values(DEFAULT,"+ kdsupplier +", "+ kdproduk +",'"+ jTextHarga.getText() +"','"+ jTextDiskon.getText() +"','"+ jTextCostPrice.getText()+"','"+ jSpinnerInStock.getValue() +"')";
                StrI.executeUpdate(SqlIPD);
            }
            JOptionPane.showMessageDialog(null, "Data Tabel Detail Produk Sudah Di Insert ","Insert",JOptionPane.INFORMATION_MESSAGE);
            datatotabel();
            bersihkanlayar();
        }catch(SQLException e){
            JOptionPane.showMessageDialog(this, "Update atau Insert Gagal\n"+e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
    }//akhir method
    
    public void HapusData()
    {
           String kodesupplier=jComboSupplier.getSelectedItem().toString();
           String kdsupplier=kodesupplier.substring(kodesupplier.length()-1);
           int selectedRow = jTableProduk.getSelectedRow();
           String idproduk = jTableProduk.getValueAt(selectedRow, 0).toString();
           
         try{
           
                Statement stat=(Statement)Koneksi_DB.GetKoneksi().createStatement();
              
                String sql1="delete from tdetailproduk where kodeproduk='"+ idproduk +"' and kodesupplier='"+ kdsupplier +"'";
                stat.executeUpdate(sql1);
             
              String sql="delete from tmasterid where itemID='"+ idproduk +"'";
              stat.executeUpdate(sql);
              
              datatotabel();
              bersihkanlayar();            
              
          
         }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage() );   
        } 
    }//end method

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel12 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextNamaProduk = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextHarga = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jComboSupplier = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jTextDiskon = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextCostPrice = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableProduk = new javax.swing.JTable();
        btnSimpan = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        btnKeluar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jSpinnerTStock = new javax.swing.JSpinner();
        jSpinnerInStock = new javax.swing.JSpinner();

        jLabel12.setText("jLabel12");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Data Produk");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Data Produk");

        jLabel3.setText("Nama Produk");

        jLabel4.setText("Price");

        jTextHarga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextHargaKeyPressed(evt);
            }
        });

        jLabel5.setText("Supplier");

        jComboSupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboSupplierActionPerformed(evt);
            }
        });

        jLabel6.setText("Diskon");

        jTextDiskon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextDiskonActionPerformed(evt);
            }
        });
        jTextDiskon.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextDiskonKeyPressed(evt);
            }
        });

        jLabel7.setText("Cost Price");

        jTextCostPrice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextCostPriceActionPerformed(evt);
            }
        });

        jTableProduk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID Produk", "Nama Produk", "Harga", "Supplier", "Diskon"
            }
        ));
        jScrollPane1.setViewportView(jTableProduk);

        btnSimpan.setText("Simpan");
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });

        btnHapus.setText("Hapus");
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });

        btnKeluar.setText("Keluar");
        btnKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKeluarActionPerformed(evt);
            }
        });

        jLabel8.setText("Total Stock");

        jLabel16.setText("InStock");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSimpan)
                        .addGap(18, 18, 18)
                        .addComponent(btnHapus)
                        .addGap(202, 202, 202)
                        .addComponent(btnKeluar))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel8)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextNamaProduk, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jTextDiskon, javax.swing.GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)
                                        .addComponent(jSpinnerTStock))
                                    .addGap(34, 34, 34)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel7)
                                        .addComponent(jLabel16))
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jTextCostPrice)
                                        .addComponent(jSpinnerInStock)))
                                .addComponent(jComboSupplier, 0, 350, Short.MAX_VALUE)
                                .addComponent(jTextHarga)))))
                .addContainerGap(18, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(155, 155, 155))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextNamaProduk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextHarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jComboSupplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTextDiskon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jTextCostPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel16)
                    .addComponent(jSpinnerTStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinnerInStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSimpan)
                    .addComponent(btnHapus)
                    .addComponent(btnKeluar))
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextCostPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextCostPriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextCostPriceActionPerformed

    private void jTextDiskonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextDiskonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextDiskonActionPerformed

    private void jTextHargaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextHargaKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextHargaKeyPressed

    private void jComboSupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboSupplierActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboSupplierActionPerformed

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        // TODO add your handling code here:
        String nama=jTextNamaProduk.getText();
        String hrg=jTextHarga.getText();
        String dis=jTextDiskon.getText();
        String cost=jTextCostPrice.getText();
        
        if(nama.isEmpty() && hrg.isEmpty() && dis.isEmpty() && cost.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Ada kolom yang masih kosong");
            jTextNamaProduk.requestFocus(); 
        }else{
            simpandata();
            datatotabel();
            bersihkanlayar();
        }//end if
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        // TODO add your handling code here:        
        int jawab = JOptionPane.showConfirmDialog(this, "Yakin Data Akan Di Hapus?"); 
              
        switch(jawab)
        {
            case JOptionPane.YES_OPTION:
                HapusData();
                JOptionPane.showMessageDialog(this, "Data Sudah Di Hapus"); 
                break; 
            case JOptionPane.NO_OPTION:
                JOptionPane.showMessageDialog(this, "Data Batal Di Hapus"); 
                break;
        }
    }//GEN-LAST:event_btnHapusActionPerformed

    private void jTextDiskonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextDiskonKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode()==KeyEvent.VK_ENTER)
        {
            if (jTextHarga.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Kolom Harga Masih Kosong");
                jTextHarga.requestFocus(); 
            }else{
                  harga=jTextHarga.getText();
                  diskon=jTextDiskon.getText();
                  
                  Double hrg=Double.parseDouble(harga);
                  Double dis=Double.parseDouble(diskon);
                  Double cost=hrg-((dis/100)*hrg);
                  
                  jTextCostPrice.setText(Double.toString(cost));                      
                   jTextCostPrice.disable();
            }
            
        }//end if
    }//GEN-LAST:event_jTextDiskonKeyPressed

    private void btnKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKeluarActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnKeluarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFrame_Produk.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFrame_Produk.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFrame_Produk.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFrame_Produk.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFrame_Produk().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnKeluar;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JComboBox<String> jComboSupplier;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinnerInStock;
    private javax.swing.JSpinner jSpinnerTStock;
    private javax.swing.JTable jTableProduk;
    private javax.swing.JTextField jTextCostPrice;
    private javax.swing.JTextField jTextDiskon;
    private javax.swing.JTextField jTextHarga;
    private javax.swing.JTextField jTextNamaProduk;
    // End of variables declaration//GEN-END:variables
}
